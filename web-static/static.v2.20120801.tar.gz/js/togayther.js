/*
 * jQuery UI Autocomplete HTML Extension
 *
 * Copyright 2010, Scott González (http://scottgonzalez.com)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 *
 * http://github.com/scottgonzalez/jquery-ui-extensions
 */
(function( $ ) {

var proto = $.ui.autocomplete.prototype,
	initSource = proto._initSource;

function filter( array, term ) {
	var matcher = new RegExp( $.ui.autocomplete.escapeRegex(term), "i" );
	return $.grep( array, function(value) {
		return matcher.test( $( "<div>" ).html( value.label || value.value || value ).text() );
	});
}

$.extend( proto, {
	_initSource: function() {
		if ( this.options.html && $.isArray(this.options.source) ) {
			this.source = function( request, response ) {
				response( filter( this.options.source, request.term ) );
			};
		} else {
			initSource.call( this );
		}
	},

	_renderItem: function( ul, item) {
		return $( "<li></li>" )
			.data( "item.autocomplete", item )
			.append( $( "<a></a>" )[ this.options.html ? "html" : "text" ]( item.label ) )
			.appendTo( ul );
	}
});

})( jQuery );

(function($){

	/**
	 * Function for setting offset, created here so it's only created once rather than
	 * creating an anonymous function every time offset is called
	 */
	function setOffset(el, newOffset){
		var $el = $(el);

		// get the current css position of the element
		var cssPosition = $el.css('position');

		// whether or not element is hidden
		var hidden = false;

		// if element was hidden, show it
		if($el.css('display') == 'none'){
			hidden = true;
			$el.show();
		}

		// get the current offset of the element
		var curOffset = $el.offset();

		// if there is no current jQuery offset, give up
		if(!curOffset){
			// if element was hidden, hide it again
			if(hidden)
				$el.hide();
			return;
		}

		// set position to relative if it's static
		if (cssPosition == 'static') {
			$el.css('position', 'relative');
			cssPosition = 'relative';
		}

		// get current 'left' and 'top' values from css
		// this is not necessarily the same as the jQuery offset
		var delta = {
			left : parseInt($el.css('left'), 10),
			top: parseInt($el.css('top'), 10)
		};

		// if the css left or top are 'auto', they aren't numbers
		if (isNaN(delta.left)){
			delta.left = (cssPosition == 'relative') ? 0 : el.offsetLeft;
		}
		if (isNaN(delta.top)){
			delta.top = (cssPosition == 'relative') ? 0 : el.offsetTop;
		}

		if (newOffset.left || 0 === newOffset.left){
			$el.css('left', newOffset.left - curOffset.left + delta.left + 'px');
		}
		if (newOffset.top || 0 === newOffset.top){
			$el.css('top', newOffset.top - curOffset.top + delta.top + 'px');
		}

		// if element was hidden, hide it again
		if(hidden)
			$el.hide();
	}

	$.fn.extend({

		/**
		 * Store the original version of offset(), so that we don't lose it
		 */
		_offset : $.fn.offset,

		/**
		 * Set or get the specific left and top position of the matched
		 * elements, relative the the browser window by calling setXY
		 * @param {Object} newOffset
		 */
		offset : function(newOffset){
			return !newOffset ? this._offset() : this.each(function(){
				setOffset(this, newOffset);
			});
		}
	});

})(jQuery);
function call( callUrl, elementId ) {
	jQuery.get(callUrl,null,function(data) { 
			$("#" +elementId).html(data); bindForms(); bindSliders(); 
	} );
}
function addPoint(markersarray,lat,lng,title,icon, map, shadowIcon,infoUrl) {
	var marker = new google.maps.Marker({position:new google.maps.LatLng(lat,lng), title :title,icon: icon, shadow : shadowIcon, map: map});
	markersarray.push(marker);
	google.maps.event.addListener(marker,'click',function() {
		jQuery.get(infoUrl,null,function(data) {
			infowindow.setContent(data);
			infowindow.open(map,marker);
		});
	});
}
function clearPoints(markersArray) {
	for(var i in markersArray) {
		markersArray[i].setMap(null);
	}
}
function computeCentralPoint(markersArray) {
	return computeBounds(markersArray).getCenter();
}
function computeBounds(markersArray) {
	var latlngbounds = new google.maps.LatLngBounds();
	for(var i in markersArray) {
		var p = markersArray[i].position;
		if(p.lat() != 0 && p.lng() != 0) {
			latlngbounds.extend(markersArray[i].position);
		}
	}
	return latlngbounds;
}
function setfocus(obj, defaultText) {
	if(defaultText == obj.value) {
		obj.value='';
	} 
}
function lostfocus(obj, defaultText) {
	if(trim(obj.value) == '') {
		obj.value=defaultText;
	} 
}
function focusComment(obj) {
	$("#comment-text").addClass("focused-comment");
	$("#comment-submit").removeClass("invisible");
	$("#comment-post-spinner").removeClass("invisible");
}
function blurComment(obj) {
	if(trim(obj.value) == '') {
		$("#comment-text").removeClass("focused-comment");
		$("#comment-submit").addClass("invisible");
		$("#comment-post-spinner").addClass("invisible");
	}
}
function trim (myString) { 
	return myString.replace(/^\s+/g,'').replace(/\s+$/g,'') 
} 
function bindForms() {
	var options = {
			target: '.msgBubbleExt',
			url: '/ajaxSendMsg.action'
	};
	jQuery('#sendMsg').ajaxForm(options);
	options = {
			target: '#instantUserMsg',
			beforeSubmit: function(arr,$form,options) {
				$("#instant-post-spinner").html("<img class='nextIcon' height='15' src='/images/loading.gif' alt='Loading...'/>");
			},
			url: '/ajaxSendInstantMsg.action'
	};
	jQuery('#instantMsgForm').ajaxForm(options);
	options = {
			target : "#comments-contents",
			url: "/postComment.action",
			beforeSubmit: function(arr,$form,options) {
				$("#comment-post-spinner").html("<img border='0' height='15' src='/images/loading.gif' alt='Loading...'/>");
			},
			success: function(responseText,statusText, xhr,$form) {
				bindForms();
			}
	};
	$("#comment-post-form").ajaxForm(options);
}
function check( elt ) {
//	var checked = document.getElementById(checkId).checked;
//	document.getElementById(checkId).checked = !checked;
//	var className = 'tag tagwidth';
//	if(!checked) {
//		className = 'selected-tag tagwidth';
//	}
//	document.getElementById('a-' + checkId).className = className;
	var id = elt.id;
	var tagId = id.substring(id.indexOf("-")+1);
	var checkbox = $("#" + tagId);
	var checked = checkbox.attr("checked");
	checkbox.attr("checked",!checked);
	$(elt).parent().toggleClass("search-facet-selected");
	
}
function checkCommentTag(checkId,url) {
	$("#tag-" + checkId).toggleClass("selected-tag");
	call(url,null);
}
function bindDefaultOverlays() {
	$("a[rel]").overlay({ mask: {
		color: '#ebecff',
		loadSpeed: 200,
		opacity: 0.9
	}, closeOnClick: true, onBeforeLoad: function() {
		// grab wrapper element inside content
		var wrap = this.getOverlay().find("#contentWrap");
		if(wrap != null) {
			// load the page specified in the trigger
			wrap.load(this.getTrigger().attr("href"));
		}
	}, onClose: function() {
		document.getElementById("contentWrap").innerHTML="";
	}});
}
function moveMedia(callUrl) {
	jQuery.get(callUrl,null,function(data) { $(".profile-media-container").html(data); handleMediaList(); initOverlays();} );
}
function simpleCall( callUrl, elementId ) {
	jQuery.get(callUrl,null,function(data) { $('#' + elementId).html(data);  } );
}
function displayMsg() {
	var current = document.getElementById('instantMsg').style.display;
	if(current == 'inline') {
		document.getElementById('instantMsg').style.display='none';
	} else {
		document.getElementById('instantMsg').style.display='inline';
	}
}
function refreshMessages(timeout) {
	var timer = setTimeout("msgCall('/ajaxInstantRefreshTitle.action','instantMsgTitle'," + timeout + ");",timeout);
	var hasMsg = document.getElementById('hasMsg').innerHTML;
	if(hasMsg == "false") {
		simpleCall('/ajaxInstantRefreshBody.action','instantMsgBody');
	}
}
function msgCall( callUrl, elementId, timeout ) {
	jQuery.get(callUrl,null,function(data) { $('#' + elementId).html(data); refreshMessages(timeout); } );
}
function bindSendMsg() {
	options = {
		target : "#mainContent",
		url:"postMessage.action",
		beforeSubmit: function(arr,$form,options) {
			$("#message-post-spinner").html("<img border='0' height='15' src='/images/loading.gif' alt='Loading...'/>");
		},
		success: function(responseText,statusText, xhr,$form) {
			bindForms();
			bindSendMsg();
		}
	}
	$("#message-post-form").ajaxForm(options);
}
function lookup( callUrl ) {
	jQuery.get(callUrl,null,function(data) { document.getElementById('cityDefinition').innerHTML = data; });
}
function like(url,target) {
	$('#likeaction').attr("src","/images/loading.gif");
	call(url, target);
}
function waitCall(url, target, loadTarget ) {
	$(loadTarget).html("<img border='0' height='24' src='/images/loading.gif' alt='Loading...'/>");
	call(url,target);
}
// Geocoding and map features
var point;
var shadowIcon; 
var geocoder;
var placeMarker;
var placeMap;
function createGMap() {
	shadowIcon = new google.maps.MarkerImage('/images/markers/shadow-marker.png',new google.maps.Size(40,36),new google.maps.Point(0,0),new google.maps.Point(12,32));
	geocoder = new google.maps.Geocoder()
	var lat = document.getElementById("place-edit-lat").value;
	var lng = document.getElementById("place-edit-lng").value;
	var placeType = document.getElementById("placeType").value;
	point = new google.maps.LatLng(lat,lng);
	var myOptions = {
      zoom: 16,
      center: point,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      disableDefaultUI: true,
      zoomControl: true
    };
	placeMap = new google.maps.Map(document.getElementById("place-map"),
            myOptions);
	var icon = new google.maps.MarkerImage('/images/markers/' + placeType + '-marker.png', new google.maps.Size(24,32),new google.maps.Point(0,0),new google.maps.Point(12,32));
	placeMarker = new google.maps.Marker({position:new google.maps.LatLng(lat, lng), icon : icon, shadow : shadowIcon, map : placeMap, draggable: true});
	google.maps.event.addListener(placeMarker,"dragend",function() {
		document.getElementById("place-edit-lat").value=placeMarker.getPosition().lat();
		document.getElementById("place-edit-lng").value=placeMarker.getPosition().lng();
		document.getElementById('place-address').value="";
		geocode();
	});
}
function geocode() {
	document.getElementById('place-edit-spinner').innerHTML = "<img border='0' height='15' src='/images/loading.gif' alt='Loading...'/>";
	var address= document.getElementById('place-address').value;
	var city = document.getElementById('city').value;
	var fullAddr = address + ", " + city;
	if(address == "") {
		var lat=  document.getElementById("place-edit-lat").value;
		var lng = document.getElementById("place-edit-lng").value;
		if(lat!="" && lng !="") {
			geocoder.geocode({"latLng" : new google.maps.LatLng(lat,lng)}, function(results,status) {
				document.getElementById('place-edit-spinner').innerHTML="";
				if(status == google.maps.GeocoderStatus.OK) {
					document.getElementById("place-address").value = results[0].formatted_address;
				}
			});
		}
	} else {
		geocoder.geocode({'address' : fullAddr}, function(results, status) {
			document.getElementById('place-edit-spinner').innerHTML="";
			if(status == google.maps.GeocoderStatus.OK) {
				var loc = results[0].geometry.location;
				placeMap.setCenter(loc);
				placeMarker.setPosition(loc);
				document.getElementById("place-edit-lat").value=loc.lat();
				document.getElementById("place-edit-lng").value=loc.lng();
			}
		});
	}
}
function mosaicInfo(obj,row,col) {
	$("#info-" + row + "-" + col).css("top: " + document.getElementById('cursorY').value)
	$("#info-" + row + "-" + col).css("left: " + document.getElementById('cursorX').value)
	$("#info-" + row + "-" + col).toggle();
}
function handleDropDown(elt, id, calType, subType) {
	var sepIndex = id.indexOf("-");
	if(sepIndex>0) {
		var parentGeoId = id.substring(sepIndex+1);
		var type = id.substring(0,sepIndex);
		if(type!="menu") {
			$('#' + id).each(function() {
				jQuery.get("/ajaxGeoList.action?type=" + calType + "&subType=" + subType + "&parent=" + parentGeoId +"&level=" + type ,null,function(data) {
					var parent = elt;
					parent.html("");
					jQuery.each(data, function() {
						var sizedLabel = this.label;
						if(this.label.length>20) {
							sizedLabel = this.label.substring(0,20) + "...";
						}
						parent.append("<li class='geo-option " + type +"-alpha'><a href='" + this.url + "'>" + sizedLabel+ "<span class='li-count'>" + this.value + "</span></a></li>");
					});
					handleDropDownLinks();
				});
			});
		}
	}
}
function handleDropDownLinks() {
	$('.dropdown a').hover(function () {
		$(this).stop(true).animate({paddingLeft: '8px'}, {speed: 100, easing: 'easeOutBack'});
	}, function () {
		$(this).stop(true).animate({paddingLeft: '0'}, {speed: 100, easing: 'easeOutBounce'});
	});
}
function addProperty(prefix, addedHeight) {
	var templateNode = $("#" + prefix+'-template');
	var template = templateNode.html();
	var container = $("#" + prefix + "-container");
	var height = Number(container.height())+Number(addedHeight);
	var heightVal = height + "px"
	container.append(template);	
	container.animate({ "height" : heightVal },500);
}
function handleDialogs() {
	$(".tag").click(function() {
		check(this);
	});
	$(".control-add").click(function() {
		var id = this.id;
		var prefix = id.substring(0,id.indexOf("-"));
		var height = id.substring(id.lastIndexOf("-")+1);
		addProperty(prefix,height);
	});
	$("input#city").autocomplete({source : "/ajaxSuggestCity.action?type=CITY", minLength:2, select: function(event, ui) {
//		lookup('/ajaxCityDefinition.action?cityKey='+ui.item.value);
		$("#city").val(ui.item.userLabel);
		$("#cityValue").val(ui.item.value);
		return false;
	}, focus: function(event, ui) { return false; }, html: true});
	$("input#place").autocomplete({source : "/ajaxSuggestCity.action?type=PLAC", minLength:2, select: function(event, ui) {
		document.getElementById("place").value=ui.item.userLabel;
		document.getElementById("placeId").value=ui.item.value;
		return false;
	}, focus: function(event, ui) { return false; },html:true});
	$("input#startDate").datepicker({dateFormat: 'yy/mm/dd'});
	$("input#endDate").datepicker({dateFormat: 'yy/mm/dd'});
}
function handleSearch() {
	var searchType= $("input#searchType").val();
	$("input#search-geo").autocomplete({
		source : "/ajaxSuggestCity.action?searchType=" + searchType, 
		minLength:2, 
		select: function(event, ui) {
			if(ui.item.value.length==4) {
			} else {
			window.location=ui.item.url; //'/searchMap.action?geoKey=' + ui.item.value;
			}
			return false;
		}, 
		focus: function(event, ui) { 
			return false; 
		}, 
		html: true
	});
}
function handleMapControls() {
	$(".map-enlarge").click(function() {
		if(enlargeEnabled) {
			center = map.getCenter();
			enlargeEnabled=false;
			$(".action-map-container").animate({
				"padding-left": "0px",
				"width": "100%",
				"top": "-335px",
				"height": "256px"
			},200, function() {
				google.maps.event.trigger(map, "resize");
				map.setCenter(center);
				minimizeEnabled=true;
			});
		}
	});
	$(".map-minimize").click(function() {
		if(minimizeEnabled) {
			center = map.getCenter();
			minimizeEnabled=false;
			$(".action-map-container").animate({
				"padding-left": "560px",
				"width": "190px",
				"top": "-275px",
				"height": "196px"
			},200, function() {
				google.maps.event.trigger(map, "resize");
				map.setCenter(center);
				enlargeEnabled=true;
			});
		}
	});
	$(".map-close").click(hideAllActions);
}
function showAction(showMap) {
	$(".action-map-controls").css("opacity","1");
	var mapOpacity = 0;
	var imgOpacity= 1;
	if(showMap) {
		mapOpacity = 1;
		imgOpacity= 0;
		$(".action-map-container").css("display","block");
		$("#map-controls").css("display","block");
		google.maps.event.trigger(map, "resize");
	} else {
		$(".action-image-container").css("display","block");
		$("#img-controls").css("display","block");
	}
	$(".action-map-container").animate({ opacity: mapOpacity},300);
	$("#map-controls").animate({ opacity: mapOpacity},300);
	$("#img-controls").animate({ opacity: imgOpacity},300);
	$(".action-image-container").animate({ opacity: imgOpacity},300,function() {
		if(showMap){
			$(".action-image-container").css("display","none");
			$("#img-controls").css("display","none");
		} else {
			$(".action-map-container").css("display","none");
			$("#map-controls").css("display","none");
		}
	});
}
function hideAllActions() {
	$(".action-map-controls").animate({ opacity: 0},300);
	$(".action-map-container").animate({ opacity: 0},300);
	$(".action-image-container").animate({ opacity: 0},300,function() {
		$(".action-map-controls").css("display","none");
		$(".action-image-container").css("display","none");
		$(".action-map-container").css("display","none");
	});
}
function initOverlays() {
	$("a[rel='#overlay']").overlay({ 
		mask: {
			color: '#ebecff',
			loadSpeed: 200,
			opacity: 0.9
			
		}, 
		fixed: false, 
		closeOnClick: true, 
		onBeforeLoad: function() {
			// grab wrapper element inside content
			jQuery.get(this.getTrigger().attr("href"), null, function(data) {
				var contentWrap = $("#contentWrap");
				contentWrap.html(data);
				var width = contentWrap.width();
				var right = (640 - width)/2+15;
				var rightPx = right + "px";
				$(".close").css("right" , rightPx);
				handleDialogs();
				initAddMedia();
			});
			
		},
		onClose: function() {
			$("#contentWrap").html("");
		}
	});
}
function initToolbar() {
	initOverlays();
	$(".tool-pictures").click(function() {
		showAction(false);
	});
	$(".tool-tmap").click(function() {
		showAction(true);
	});
	$("a[rel='ajax-image']").click(function(e) {
		e.preventDefault();
		jQuery.get("/ajaxMedia.action?id=" + this.id, null, function(data) {
			if(!imageOverlay) {
				$("#image-container-1").html(data).animate({opacity:1},300);
				$("#image-container").animate({opacity:0},300);
			} else {
				$("#image-container").html(data);
				$("#image-container-1").animate({opacity:0},300);
				$("#image-container").animate({opacity:1},300);
			}
			imageOverlay=!imageOverlay;
		});
	});
	$(".tool").hoverIntent({
		timeout:500, 
		over : function() { 
			$(".tooltip-" + lastId).hide();
			var tooltip = $(".tooltip-" + this.id);
			var left =$(this).position().left+4;
			tooltip.css("left",left);
			tooltip.show();
			lastId = this.id;
		}, 
		out : function() {
			$(".tooltip-" + this.id).hide();
		}
	});
}
function handleMediaList() {
	$(".user-media").hoverIntent({
		timeout: 0,
		over: function() {
			$(".media-actions",this).fadeIn(50);
		},
		out: function() {
			$(".media-actions",this).fadeOut(50);
		} 
	});
}
//	function bindForms() {
//   		var options = {
//   				target: '#instantMsg',
//   				url: 'ajaxSendMsg.action'
//   		};
//   		jQuery('#sendMsg').ajaxForm(options);
//		options = {
//				target: '#instantUserMsg',
//				url: 'ajaxSendInstantMsg.action'
//		};
//		jQuery('#instantMsgForm').ajaxForm(options);
//   	}