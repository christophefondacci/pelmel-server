function updateSlider( id ) {
	var minEltLabel = document.getElementById(id + "-min-label");
	if(minEltLabel != null) {
	var min = $('#' + id + '-slider').slider("values",0);
	var max = $('#' + id + '-slider').slider("values",1);
	document.getElementById(id + "-min-label").innerHTML = min;
	document.getElementById(id + "-max-label").innerHTML = max;
	}
}
function createSlider( id ) {
	var minElt = document.getElementById(id + "Min");
	if(minElt != null) {
	var min = document.getElementById(id + "Min").value;
	var max = document.getElementById(id + "Max").value;
	var currMin = document.getElementById(id + "CurrentMin").value;
	var currMax = document.getElementById(id + "CurrentMax").value;
$("#" + id + "-slider").slider({
	range: true,
	min: parseInt(min),
	max: parseInt(max),
	values: [parseInt(currMin), parseInt(currMax)],
	slide: function(event, ui) {
		updateSlider( id );
	},
	stop: function(event, ui) {
		var urlPattern = document.getElementById(id + "Url").value;
		var url = urlPattern.replace("_min_",document.getElementById(id + "-min-label").innerHTML);
		url = url.replace("_max_",document.getElementById(id + "-max-label").innerHTML);
		if(url.match("ajax")=="ajax") {
			call(url,"mainContent");
		} else {
			window.open(url,"_self");
		}
	}
});
}
}

function bindSliders() {
createSlider("age");
createSlider("weight");
createSlider("height");
updateSlider("age");
updateSlider("weight");
updateSlider("height");
}